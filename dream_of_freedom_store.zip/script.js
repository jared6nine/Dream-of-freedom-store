
console.log('Dream of Freedom Store loaded successfully.');
